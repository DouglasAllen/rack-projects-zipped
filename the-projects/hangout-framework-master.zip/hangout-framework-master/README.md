Demo Rack framework for March 6th, 2013 Ruby Hangout.
