# Best Quotes

This is the "Best Quotes" example application from the book
"Rebuilding Rails" by Noah Gibbs.  You can find the canonical branch
of this framework at "http://github.com/noahgibbs/best_quotes".

It really only exists to give Rulers something to serve up.

The code is still free to use if you want to.  I just don't know why
you'd want to.
