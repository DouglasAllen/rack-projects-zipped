module Rack
  class Server
    
    def self.start
      
    end
    def self.middleware
      
    end
    def initialize(options = nil)
      
    end
    def options
      
    end
    def app
      
    end
    def middleware
      
    end
    def start
      
    end
    def server
      
    end
    
  end
end