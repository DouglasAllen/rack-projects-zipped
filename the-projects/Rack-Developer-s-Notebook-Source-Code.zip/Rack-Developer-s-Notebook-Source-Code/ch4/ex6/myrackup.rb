#!/usr/bin/env ruby

require 'rack'
Rack::Server.start