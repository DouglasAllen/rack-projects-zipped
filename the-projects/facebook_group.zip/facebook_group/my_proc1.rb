# my_proc1.rb
my_proc = lambda {puts 'Proc Called'}
my_proc.call
 
# ruby my_proc1.rb
 
#=> Proc Called
