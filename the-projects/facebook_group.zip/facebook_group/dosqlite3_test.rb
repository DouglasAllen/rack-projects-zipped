require 'rubygems'
require 'do_sqlite3'