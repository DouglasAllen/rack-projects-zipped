gittest/gh-pages branch
========

This repo is for my course at [*RubyLearning.org*](http://rubylearning.org/classes)

Git-GitHub 7th batch


[*gittest gh-pages*](http://douglasallen.github.com/gittest/)
