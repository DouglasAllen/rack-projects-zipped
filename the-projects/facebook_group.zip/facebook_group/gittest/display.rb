class Display < MotorCycle
  def dispAttr
    'Color of MotorCycle is ' + @color
    'Make  of MotorCycle is ' + @make
  end
end