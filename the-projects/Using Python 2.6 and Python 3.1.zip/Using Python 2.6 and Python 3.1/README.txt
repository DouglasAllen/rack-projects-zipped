b*****************************************************************
Thank you for downloading the source code for 
          "Beginning Python: Using Python 2.6 and Python 3.1".
*****************************************************************

The source code for the following chapters are included:

Chapter 1  - No source code provided.

Chapter 2  - No source code provided.

Chapter 3  - No source code provided.

Chapter 4  - No source code provided.

Chapter 5  - Contains the various code listings.

Chapter 6  - Contains the various code listings.

Chapter 7  - Contains the various code listings.

Chapter 8  - Contains the various code listings.

Chapter 9  - Contains the various code listings.

Chapter 10 - Contains the various code listings.

Chapter 11 - Contains the various code listings.

Chapter 12 - Contains the various code listings.

Chapter 13 - No Source Code Provided.

Chapter 14 - Contains the various code listings.

Chapter 15 - Contains the various code listings.

Chapter 16 - Contains the various code listings.

Chapter 17 - Contains the various code listings.

Chapter 18 - No Source Code Provided.

Chapter 19 - Contains the various code listings.

Chapter 20 - No Source Code Provided

Chapter 21 - Contains the various code listings.

Appendix A - No Source Code Provided. 

Appendix B - No source code provided.

Appendix C - No source code provided.

-----------------------------------------------------------------
Please use the Errata form for the book on www.wrox.com to send
comments, bug reports, etc.
-----------------------------------------------------------------