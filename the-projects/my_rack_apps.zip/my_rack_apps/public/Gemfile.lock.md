```ruby
GEM
  remote: http://rubygems.org/
  specs:
    rack (1.6.0)
    rack-proxy (0.5.17)
      rack
    rulers (0.0.1)
      rack

PLATFORMS
  ruby

DEPENDENCIES
  rack
  rack-proxy
  rulers
```