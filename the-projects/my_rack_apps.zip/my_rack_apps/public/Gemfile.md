```ruby
source 'http://rubygems.org'

ruby '2.2.0'
gem 'rulers'#, :path => "../rulers"
gem 'rack'
gem 'rack-proxy'
```