```ruby
web: bundle exec rackup config.ru -p $PORT 
```