<<EOF
Hello, world!
Does this print?
EOF

exec "ruby simple_sinatra.rb"

puts "This Ruby script now runs alongside simple_sinatra.rb"